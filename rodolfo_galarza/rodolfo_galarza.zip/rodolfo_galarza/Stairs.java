import java.awt.*;
public class Stairs extends Frame{
	 public static void main(String[] args) {
		 
		 
	      new Fr3D(args.length > 0 ? args[0] : null, new Stairs(), 
	         "ZBuf");
	   }
}
